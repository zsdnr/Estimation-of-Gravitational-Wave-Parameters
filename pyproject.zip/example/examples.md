# Parameter Estimation with JaxGW

In this subfolder we host the examples and tools for parameter estimation in gravitational-wave.

### Single event analysis

### Injection recovery

### Population analysis

### Batch runs

gen_injection_config.py

injection_withParser.py

make_ppPlot.py

RealDataAnalysis.py