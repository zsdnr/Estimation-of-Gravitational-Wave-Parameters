# Single event Parameter Estimation

<a href="https://colab.research.google.com/drive/1ah_mwVpn3A32jhctA6BTj-Nqk7SGf9Dj?usp=sharing">
<img src="https://img.shields.io/badge/open_in_colab-GW150914-orange?logo=googlecolab" alt="doc"/>
</a>

